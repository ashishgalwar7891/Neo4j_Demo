package com.infybuzz.request;

public class CreateDepartmentRequest {

	private String depName;

	public String getDepName() {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

}
